import './App.css';
import { Routes, Route, BrowserRouter } from 'react-router-dom'
import Test from './pages/Test'
import Header from './components/Header/Header';

function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path="/test" element={<Test />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
