import './App.css';
import { Routes, Route, BrowserRouter } from 'react-router-dom'
import Header from './components/Header/Header';
import MainContent from './components/MainContent/MainContent/MainContent';
import Join from './components/MainContent/Join/Join';
import News from './components/MainContent/News/News';
import AboutUs from './components/MainContent/AboutUs/AboutUs';
import ForScouts from './components/MainContent/ForScouts/ForScouts';
import Team from './components/MainContent/Team/Team';
import Footer from './components/Footer/Footer';

function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        {/* <Route path="/test" element={<Test />} /> */}
        <Route path="/" element={<MainContent />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/news" element={<News />} />
        <Route path="/team" element={<Team />} />
        <Route path="/for-scouts" element={<ForScouts />} />
        <Route path="/join" element={<Join />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  );
}

export default App;
