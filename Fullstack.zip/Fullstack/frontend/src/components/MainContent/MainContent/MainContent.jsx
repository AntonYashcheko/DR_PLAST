import CSSclass from "./MainContent.module.css"

const MainContent = (props) => {
    return (
        <div>
            <p className={CSSclass.test}>MainContent1</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
            <p className={CSSclass.test}>MainContent</p>
        </div>
    );
}

export default MainContent;