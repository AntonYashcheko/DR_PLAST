import CSSclass from "./AboutUs.module.css"

const AboutUs = (props) => {
    return (
        <div>
            About Us
        </div>
    );
}

export default AboutUs;