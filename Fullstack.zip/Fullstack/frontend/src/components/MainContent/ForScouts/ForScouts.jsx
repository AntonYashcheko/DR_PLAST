import CSSclass from "./ForScouts.module.css"

const ForScouts = (props) => {
    return (
        <div>
            For scouts
        </div>
    );
}

export default ForScouts;