import CSSclass from "./Team.module.css"

const Team = (props) => {
    return (
        <div>
            Team
        </div>
    );
}

export default Team;