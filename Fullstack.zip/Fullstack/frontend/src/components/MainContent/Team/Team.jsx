import CSSclass from "./Team.module.css";
import { useState, useEffect } from "react";
import { Container, Row, Col } from "react-bootstrap";

import 'bootstrap/dist/css/bootstrap.min.css';
const Team = (props) => {
    const [teams, setTeams] = useState([]);

    const getTeams = async () => {
        const response = await fetch("http://127.0.0.1:8000/api/v1/team/");
        const data = await response.json();
        console.log(data)
        setTeams(data);
    }

    useEffect(() => {
        getTeams();
    }, [])
    // row-cols-lg-3 g-4 g-lg-3 
    return (
        <Container className="">
            <Row className={"row-cols-lg-3 g-4 g-lg-3 "} >
                {teams.map(teamMember =>
                    <Col key={teamMember.id} className={CSSclass.teamInfo} md={6} xs={12} lg={4}>

                        <div className={CSSclass.teamDiv} style={{
                            backgroundImage: `url(${teamMember.photo})`,
                            backgroundSize: 'cover',
                            marginLeft: '10px',
                            marginBottom: '10px',
                            borderRadius: '10px'
                        }}>
                            <div className={CSSclass.teamDescribe}>
                                <span>{teamMember.name}</span>
                                <p>{teamMember.work_place}</p>
                            </div>
                        </div>
                    </Col>
                )}
            </Row>
        </Container >




    );
}

export default Team;