import CSSclass from "./Team.module.css";
import { useState, useEffect } from "react";

const Team = (props) => {
    const [teams, setTeams] = useState([]);
    const [teamsImages, setImages] = useState([]);

    const getTeams = async() => {
        const response1 = await fetch("http://127.0.0.1:8000/api/v1/team/");
        const data1 = await response1.json();
        setTeams(data1);

        const response2 = await fetch("http://127.0.0.1:8000/api/v1/team_image/")
        const data2 = await response2.blob();
        setImages(data2);
        console.log(data2);
       
    }

    useEffect(()=>{
        getTeams();
    },[])
    
    return (
        <div>
            {teams.map(teamMember => <h1 key={teamMember.id}>{teamMember.name}
            </h1>)}
            {teamsImages.map(teamImg => <img key={teamImg.id} src={teamImg.photo}>
            </img>)}
        </div>
    );
}

export default Team;