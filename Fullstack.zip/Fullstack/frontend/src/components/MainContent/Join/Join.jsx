import CSSclass from "./Join.module.css"

const Join = (props) => {
    return (
        <div>
            Join
        </div>
    );
}

export default Join;