import CSSclass from "./News.module.css"

const News = (props) => {
    return (
        <div>
            News
        </div>
    );
}

export default News;