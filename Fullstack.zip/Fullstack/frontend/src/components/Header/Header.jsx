import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import CSSclass from "./Header.module.css"
import LogoImage from './LogoImage/LogoImage';
import NavLinks from './NavLinks/NavLinks';
import { Container, Nav, Navbar, NavDropdown, Dropdown } from 'react-bootstrap';
import { NavLink } from 'react-router-dom';

import 'bootstrap/dist/css/bootstrap.min.css';

const Header = () => {
    return (
        // <header className={CSSclass.header_nav} >
        //    <LogoImage />
        //    <NavLinks />
        // </header>
        // <Navbar bg="light" expand="lg">
        //     <Container>
        //         <Navbar.Brand><LogoImage /></Navbar.Brand>
        //         <Navbar.Toggle aria-controls="basic-navbar-nav"/>
        //         <Navbar.Collapse id="basic-navbar-nav"></Navbar.Collapse>
        //         <Nav className="me-auto">
        //             <NavLinks />
        //         </Nav>
        //     </Container>
        // </Navbar>
        // <Navbar bg="light" expand="lg" className={CSSclass.navbar}>
        //     <Container className={CSSclass.container}>
        //         <Navbar.Brand><LogoImage /></Navbar.Brand>
        //         <Navbar.Toggle aria-controls="basic-navbar-nav" />
        //         <Navbar.Collapse id="basic-navbar-nav">
        //             <NavLinks />
        //         </Navbar.Collapse>
        //     </Container>
        // </Navbar>
        
        <Navbar bg="light" expand="lg" className={CSSclass.header_nav}>
            <Container fluid>
                <Navbar.Brand href="#"><LogoImage /></Navbar.Brand>
                <Navbar.Toggle aria-controls="navbarScroll" />
                <Navbar.Collapse id="navbarScroll">
                    <Nav
                        className={"me-auto my-2 my-lg-0" + ' ' + CSSclass.navlinks}
                        style={{ maxHeight: '400px' }}
                        navbarScroll
                    >
                        <NavLink to='/' className={navData => navData.isActive ? CSSclass.active : CSSclass.no_active}>Головна</NavLink>
                        <NavLink to='/about' className={navData => navData.isActive ? CSSclass.active : CSSclass.no_active}>Про Пласт</NavLink>
                        <NavLink to='/news' className={navData => navData.isActive ? CSSclass.active : CSSclass.no_active}>Новини</NavLink>
                        <NavLink to='/team' className={navData => navData.isActive ? CSSclass.active : CSSclass.no_active}>Команда</NavLink>
                        <NavLink to='/for-scouts' className={navData => navData.isActive ? CSSclass.active : CSSclass.no_active}>Для пластунів</NavLink>
                        <NavLink to='/join' className={navData => navData.isActive ? CSSclass.active : CSSclass.no_active}>Долучитись</NavLink>
                        <Dropdown className={CSSclass.dropdown}>
                            <Dropdown.Toggle variant="success" id="dropdown-basic" className={CSSclass.support}>
                                Підтримати
                            </Dropdown.Toggle>

                            <Dropdown.Menu >
                                <Dropdown.Item href="#/action-1" >PayPal</Dropdown.Item>
                                <Dropdown.Item href="#/action-2" >Amazon</Dropdown.Item>
                            </Dropdown.Menu>
                        </Dropdown>
                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
};

export default Header;
