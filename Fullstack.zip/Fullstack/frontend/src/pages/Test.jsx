import {react,useEffect,useState} from 'react'

const Test = () => {

    const [names,setNames] = useState([])

    const getNames = async () => {
        const response = await fetch('http://127.0.0.1:8000/api/v1/test/')
        const data = await response.json()
        setNames(data)
    }

    useEffect(()=>{
        getNames()
    },[])

    return names.map(nameObj=> <h1 key={nameObj.key}>{nameObj.name}</h1>)
    
}

export default Test