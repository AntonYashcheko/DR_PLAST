from django.db import models

# Create your models here.
class Test(models.Model):
    name = models.CharField(max_length=100)


class Team(models.Model):
    name = models.CharField(max_length=50)
    work_place  = models.CharField(max_length=50)


class TeamImage(models.Model):
    photo = models.ImageField(upload_to="frontend/src/assets/imgs/%Y/%m/%d/",verbose_name='Фото')
    team_id = models.ForeignKey(Team, null=True ,on_delete=models.SET_NULL)

