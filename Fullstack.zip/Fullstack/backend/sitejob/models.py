from django.db import models

# Create your models here.
class Test(models.Model):
    name = models.CharField(max_length=100)


class Team(models.Model):
    name = models.CharField(max_length=50)
    work_place  = models.CharField(max_length=50)
    photo = models.ImageField(upload_to="imgs/%Y/%m/%d/",verbose_name='Фото')




