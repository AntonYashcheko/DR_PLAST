from django.shortcuts import render
from rest_framework import generics
from .models import *
from .serializer import TestSerializer
# Create your views here.
class NameAPIList(generics.ListAPIView):
    queryset = Test.objects.all()
    serializer_class  = TestSerializer
    