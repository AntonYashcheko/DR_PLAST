from django.shortcuts import render
from rest_framework import generics
from .models import *
from .serializer import *
from rest_framework import mixins
from rest_framework.viewsets import GenericViewSet
# Create your views here.
class NameAPIList(generics.ListAPIView):
    queryset = Test.objects.all()
    serializer_class  = TestSerializer
    

class TeamAPIVIEWSET(mixins.ListModelMixin,GenericViewSet):
    queryset = Team.objects.all()
    serializer_class  = TeamSerializer

class TeamImgAPIVIEWSET(mixins.ListModelMixin,GenericViewSet):
    queryset = TeamImage.objects.all()
    serializer_class  = TeamImgSerializer
