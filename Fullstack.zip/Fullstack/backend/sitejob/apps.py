from django.apps import AppConfig


class SitejobConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sitejob'
