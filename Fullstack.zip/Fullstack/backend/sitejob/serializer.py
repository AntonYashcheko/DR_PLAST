from rest_framework import serializers
from  .models import *

class TestSerializer(serializers.ModelSerializer):
    class Meta:
        model = Test
        fields = '__all__'

class TeamSerializer(serializers.ModelSerializer):
    class Meta:
        model = Team
        fields = '__all__'


class TeamImgSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeamImage
        fields = '__all__'